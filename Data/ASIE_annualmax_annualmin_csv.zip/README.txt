This dataset contains the annual maximum (greatest magnitude of each year) and minimum (smallest magnitude of each year) of Antarctic sea ice extent [10^6 km^2]. From 1979-2024 for minimum. From 1979-2023 for maximum.

Files included:
 1. annualmax.csv: Contains the following columns:
    Column 1 - Years
    Column 2 - Ross Maximum
    Column 3 - Amundsen-Bellingshausen Maximum
    Column 4 - Weddell Maximum
    Column 5 - King Hakon Maximum
    Column 6 - East Antarctica Maximum
    Column 7 - Total (Continental) Maximum

 2. annualmin.csv: Contains the following columns:
    Column 1 - Years
    Column 2 - Ross Day Minimum
    Column 3 - Amundsen-Bellingshausen Minimum
    Column 4 - Weddell Day Minimum
    Column 5 - King Hakon Minimum
    Column 6 - East Antarctica Minimum
    Column 7 - Total (Continental) Minimum
