This dataset contains the Traditional, Invariant, Amplitude-Adjusted, Phase-Adjusted, and Amplitude-and-Phase-Adjusted Cycles of  Antarctica sea ice extent, calculated using data spanning 1979 to 2023. See Handcock and Raphael 2019. 

Files included:
 1. traditional_cycle.csv: Contains the following columns:
    Column 1 - Day of cycle
    Column 2 - Traditional Cycle of Antarctic sea ice extent in the Ross Sea
    Column 3 - Traditional Cycle of Antarctic sea ice extent in the Amundsen-Bellingshausen Seas
    Column 4 - Traditional Cycle of Antarctic sea ice extent in the Weddell Sea
    Column 5 - Traditional Cycle of Antarctic sea ice extent in the King Hakon Sea
    Column 6 - Traditional Cycle of Antarctic sea ice extent in East Antarctica
    Column 7 - Traditional Cycle of total (continental) Antarctic sea ice extent

 2. invariant_cycle.csv: Contains the following columns:
    Column 1 - Day of cycle
    Column 2 - Invariant Cycle of Antarctic sea ice extent in the Ross Sea
    Column 3 - Invariant Cycle of Antarctic sea ice extent in the Amundsen-Bellingshausen Seas
    Column 4 - Invariant Cycle of Antarctic sea ice extent in the Weddell Sea
    Column 5 - Invariant Cycle of Antarctic sea ice extent in the King Hakon Sea
    Column 6 - Invariant Cycle of Antarctic sea ice extent in East Antarctica
    Column 7 - Invariant Cycle of total (continental) Antarctic sea ice extent

 3. amplitude_adjusted_cycle.csv: Contains the following columns:
    Column 1 - Years
    Column 2 - Day of cycle
    Column 3 - Amplitude-Adjusted Cycle of Antarctic sea ice extent in the Ross Sea
    Column 4 - Amplitude-Adjusted Cycle of Antarctic sea ice extent in the Amundsen-Bellingshausen Seas
    Column 5 - Amplitude-Adjusted Cycle of Antarctic sea ice extent in the Weddell Sea
    Column 6 - Amplitude-Adjusted Cycle of Antarctic sea ice extent in the King Hakon Sea
    Column 7 - Amplitude-Adjusted Cycle of Antarctic sea ice extent in East Antarctica
    Column 8 - Amplitude-Adjusted Cycle of total (continental) Antarctic sea ice extent

 4. phase_adjusted_cycle_ross.csv: Contains the following columns:
    Column 1 - Years
    Column 2 - Day of cycle
    Column 3 - Phase-Adjusted Cycle of Antarctic sea ice extent in the Ross Sea

 5. phase_adjusted_cycle_bell.csv: Contains the following columns:
    Column 1 - Years
    Column 2 - Day of cycle
    Column 3 - Phase-Adjusted Aycle of Antarctic sea ice extent in the Amundsen-Bellingshausen Seas

 6. phase_adjusted_cycle_wed.csv: Contains the following columns:
    Column 1 - Years
    Column 2 - Day of cycle
    Column 3 - Phase-Adjusted Cycle of Antarctic sea ice extent in the Weddell Sea

 7. phase_adjusted_cycle_kh.csv: Contains the following columns:
    Column 1 - Years
    Column 2 - Day of cycle
    Column 3 - Phase-Adjusted Cycle of Antarctic sea ice extent in the King Hakon Sea

 8. phase_adjusted_cycle_ea.csv: Contains the following columns:
    Column 1 - Years
    Column 2 - Day of cycle
    Column 3 - Phase-Adjusted Cycle of Antarctic sea ice extent in East Antarctica

 9. phase_adjusted_cycle_tot.csv: Contains the following columns:
    Column 1 - Years
    Column 2 - Day of cycle
    Column 3 - Phase-Adjusted Cycle of total (continental) Antarctic sea ice extent

 10. APAC_ross.csv: Contains the following columns:
    Column 1 - Years
    Column 2 - Day of cycle
    Column 3 - Amplitude-and-Phase-adjusted (APAC) Cycle of Antarctic sea ice extent in the Ross Sea

 11. APAC_bell.csv: Contains the following columns:
    Column 1 - Years
    Column 2 - Day of cycle
    Column 3 - Amplitude-and-Phase-adjusted (APAC) Cycle of Antarctic sea ice extent in the Amundsen-Bellingshausen Sea

 12. APAC_wed.csv: Contains the following columns:
    Column 1 - Years
    Column 2 - Day of cycle
    Column 3 - Amplitude-and-Phase-adjusted (APAC) Cycle of Antarctic sea ice extent in the Weddell Sea

 13. APAC_kh.csv: Contains the following columns:
    Column 1 - Years
    Column 2 - Day of cycle
    Column 3 - Amplitude-and-Phase-Adjusted (APAC) Cycle of Antarctic sea ice extent in the King Hakon Sea

 14. APAC_ea.csv: Contains the following columns:
    Column 1 - Years
    Column 2 - Day of cycle
    Column 3 - Amplitude-and-Phase-Adjusted (APAC) Cycle of Antarctic sea ice extent in East Antarctica

 15. APAC_tot.csv: Contains the following columns:
    Column 1 - Years
    Column 2 - Day of cycle
    Column 3 - Amplitude-and-Phase-Adjusted (APAC) Cycle of total (continental) Antarctic sea ice extent

