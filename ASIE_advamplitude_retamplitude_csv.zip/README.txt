This dataset contains the annual advance amplitude (max_extent(year)-min_extent(year)) and annual retreat amplitude (max_extent(year)-min_extent(year+1)) of Antarctic sea ice extent [10^6 km^2]. From 1979-2023 for both advance and retreat amplitudes.

Files included:
 1. advamplitude.csv: Contains the following columns:
    Column 1 - Years
    Column 2 - Ross Advance Amplitude
    Column 3 - Amundsen-Bellingshausen Advance Amplitude
    Column 4 - Weddell Advance Amplitude
    Column 5 - King Hakon Advance Amplitude
    Column 6 - East Antarctica Advance Amplitude
    Column 7 - Total (Continental) Advance Amplitude

 2. retamplitude.csv: Contains the following columns:
    Column 1 - Years
    Column 2 - Ross Day Retreat Amplitude
    Column 3 - Amundsen-Bellingshausen Retreat Amplitude
    Column 4 - Weddell Day Retreat Amplitude
    Column 5 - King Hakon Retreat Amplitude
    Column 6 - East Antarctica Retreat Amplitude
    Column 7 - Total (Continental) Retreat Amplitude
