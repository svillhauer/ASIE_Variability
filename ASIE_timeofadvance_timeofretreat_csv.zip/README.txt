This dataset contains the time of Antarctic sea ice extent advance and retreat in decimal Julian days and decimal years. From 1979-2024 for day of advance. From 1979-2023 for day of retreat.

Files included:
 1. advance_decimaljuliandays.csv: Contains the following columns:
    Column 1 - Years
    Column 2 - Ross Time of Advance in Decimal Julian Days
    Column 3 - Amundsen-Bellingshausen JTime of Advance in Decimal Julian Days
    Column 4 - Weddell Time of Advance in Decimal Julian Days
    Column 5 - King Hakon Time of Advance in Decimal Julian Days
    Column 6 - East Antarctica Time of Advance in Decimal Julian Days
    Column 7 - Total (Continental) Time of Advance in Decimal Julian Days

 2. advance_decimalyears.csv: Contains the following columns:
    Column 1 - Years
    Column 2 - Ross Time of Advance in Decimal Years
    Column 3 - Amundsen-Bellingshausen Time of Advance in Decimal Years
    Column 4 - Weddell Time of Advance in Decimal Years
    Column 5 - King Hakon Time of Advance in Decimal Years
    Column 6 - East Antarctica Time of Advance in Decimal Years
    Column 7 - Total (Continental) Time of Advance in Decimal Years

 3. retreat_decimaljuliandays.csv: Contains the following columns:
    Column 1 - Years
    Column 2 - Ross Time of Retreat in Decimal Julian Days
    Column 3 - Amundsen-Bellingshausen Time of Retreat in Decimal Julian Days
    Column 4 - Weddell Time of Retreat in Decimal Julian Days
    Column 5 - King Hakon Time of Retreat in Decimal Julian Days
    Column 6 - East Antarctica Time of Retreat in Decimal Julian Days
    Column 7 - Total (Continental) Time of Retreat in Decimal Julian Days

 4. retreat_decimalyears.csv: Contains the following columns:
    Column 1 - Years
    Column 2 - Ross Time of Retreat in Decimal Years
    Column 3 - Amundsen-Bellingshausen Time of Retreat in Decimal Years
    Column 4 - Weddell Time of Retreat in Decimal Years
    Column 5 - King Hakon Time of Retreat in Decimal Years
    Column 6 - East Antarctica Time of Retreat in Decimal Years
    Column 7 - Total (Continental) Time of Retreat in Decimal Years
